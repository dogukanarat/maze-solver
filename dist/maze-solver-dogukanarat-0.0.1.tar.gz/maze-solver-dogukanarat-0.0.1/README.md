# maze-solver
Maze Solving and Vehicle Routing Algorithm

[![Build Status](https://travis-ci.com/ieee-uv-project/maze-solver.svg?branch=master)](https://travis-ci.com/ieee-uv-project/maze-solver)

## find_path
It solves the given maze image and saves the path in binary format.

## find_route
It takes the binary image and exacts the path using algorithm, then save it as datafile
